// Background service worker. Three jobs, all requiring the background
// context specifically (none of this can run in the Earth content script):
//
// 1. chrome.tabs.captureVisibleTab for the "Screenshot" toolbar button —
//    content scripts cannot call chrome.tabs.* at all.
// 2. Opening the TurnKey-hosted measurement workspace (measure.html) in its
//    own tab, injecting the content bridge into it once it loads, and
//    routing the finished measurement back to the right Google Earth tab.
// 3. A narrow, allowlisted TurnKey API proxy (TK_API messages) so the Earth
//    content script never has to `fetch()` Supabase directly from inside
//    earth.google.com's page context.
//
// MV3 service workers are suspended after ~30s of inactivity and can be
// killed/restarted between any two messages — an in-memory Map alone would
// silently lose every pending measurement request on a real, long (several
// minutes) property trace. The pending-request registry is therefore
// backed by chrome.storage.session (cleared when the browser session ends,
// but NOT on worker suspension/restart, unlike chrome.storage.local which
// would needlessly survive a full browser restart for what's meant to be a
// short-lived handshake) — see loadPending()/savePending() below.
import { fetchSiteConfig, TurnKeyClient, TURNKEY_CRM_ORIGINS, TURNKEY_SUPABASE_ORIGIN } from '../api/turnkey-api.js';
import { recoverFromCRM } from './session-recovery.js';
import { Storage, connectionChanged } from '../api/storage.js';
import { dataUrlToBlob } from '../content/panel/screenshot.js';
import { openTurnKeyTab } from './open-turnkey.js';
import { registerCustomerHandoff } from './customer-handoff.js';

// Customer → Google Earth handoff (TK_CUSTOMER_LAUNCH / TK_GET_CUSTOMER_CONTEXT) — see customer-handoff.js.
registerCustomerHandoff(ensureClient);

// ── 1. Screenshot ────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'CAPTURE_SCREENSHOT') {
    const windowId = sender.tab ? sender.tab.windowId : chrome.windows.WINDOW_ID_CURRENT;
    chrome.tabs.captureVisibleTab(windowId, { format: 'png' }, (dataUrl) => {
      if (chrome.runtime.lastError) sendResponse({ ok: false, error: chrome.runtime.lastError.message });
      else sendResponse({ ok: true, dataUrl });
    });
    return true;
  }
  return false;
});

// ── 2. Measurement workspace bridge ─────────────────────────────────────
const EARTH_ORIGIN = 'https://earth.google.com';
const REQUEST_TTL_MS = 2 * 60 * 60 * 1000; // 2 hours — generous for a slow multi-angle 3D trace, still bounded
const PENDING_KEY = 'tk_pending_measure_requests';

// Origins the bridge script (extension/content/bridge/measure-bridge.js)
// can actually be injected AND import geometry.js into — must exactly
// match manifest.json's static web_accessible_resources matches for
// geometry.js, since that list can't be extended at runtime the way
// host_permissions can. Keep these two lists in sync by hand; there's no
// single source of truth that can generate manifest.json's JSON and this
// JS array both without a build step.
const BRIDGE_ALLOWED_ORIGINS = new Set([
  'https://turnkeycrm.net',
  'http://localhost',
  'http://localhost:5173',
  'http://localhost:8888',
  'http://127.0.0.1',
  'http://127.0.0.1:5173',
  'http://127.0.0.1:8888'
]);

/** requestId -> {earthTabId, workspaceTabId, category, kind, createdAt, completed, bridged} */
export const pendingRequests = new Map();
let loaded = false;
let loadingPromise = null;

async function loadPending() {
  if (loaded) return;
  if (!loadingPromise) {
    loadingPromise = (async () => {
      try {
        const data = await chrome.storage.session.get(PENDING_KEY);
        const stored = data[PENDING_KEY] || {};
        for (const [id, req] of Object.entries(stored)) pendingRequests.set(id, req);
      } catch {
        // chrome.storage.session unavailable (older Chrome) — pending
        // requests just won't survive a worker restart; still correct
        // within a single worker lifetime.
      }
      loaded = true;
    })();
  }
  await loadingPromise;
}

async function savePending() {
  try {
    await chrome.storage.session.set({ [PENDING_KEY]: Object.fromEntries(pendingRequests) });
  } catch {
    // best-effort — see loadPending()'s catch
  }
}

async function sweepExpired(now = Date.now()) {
  await loadPending();
  let changed = false;
  for (const [id, req] of pendingRequests) {
    if (now - req.createdAt > REQUEST_TTL_MS) {
      pendingRequests.delete(id);
      changed = true;
    }
  }
  if (changed) await savePending();
}

function randomRequestId() {
  return (globalThis.crypto && globalThis.crypto.randomUUID) ? globalThis.crypto.randomUUID() : 'r' + Date.now() + '_' + Math.random().toString(36).slice(2);
}

function bridgeOriginAllowed(siteUrl) {
  try {
    return BRIDGE_ALLOWED_ORIGINS.has(new URL(siteUrl).origin);
  } catch {
    return false;
  }
}

async function openWorkspace({ category, categoryLabel, kind, lat, lng, address, propertyLat, propertyLng }, earthTabId) {
  await sweepExpired();
  const config = await Storage.getConfig();
  if (!config || !config.siteUrl) throw new Error('Connect the extension to your TurnKey site first.');
  if (!bridgeOriginAllowed(config.siteUrl)) {
    throw new Error(
      `The measurement workspace's secure bridge isn't enabled for ${new URL(config.siteUrl).origin} yet — it works automatically for https://turnkeycrm.net and local development. Ask whoever manages this TurnKey extension build to add your site's origin, or connect the extension to turnkeycrm.net instead.`
    );
  }
  const requestId = randomRequestId();
  const url = new URL(config.siteUrl.replace(/\/+$/, '') + '/measure.html');
  url.searchParams.set('requestId', requestId);
  url.searchParams.set('category', category);
  url.searchParams.set('label', categoryLabel || category);
  url.searchParams.set('kind', kind);
  url.searchParams.set('lat', String(lat));
  url.searchParams.set('lng', String(lng));
  if (typeof address === 'string' && address.trim()) url.searchParams.set('address', address.trim().slice(0, 500));
  if (Number.isFinite(propertyLat) && Math.abs(propertyLat) <= 85 && Number.isFinite(propertyLng) && Math.abs(propertyLng) <= 180) {
    url.searchParams.set('propertyLat', String(propertyLat));
    url.searchParams.set('propertyLng', String(propertyLng));
  }
  const tab = await chrome.tabs.create({ url: url.toString(), active: true });
  pendingRequests.set(requestId, {
    earthTabId,
    workspaceTabId: tab.id,
    category,
    kind,
    createdAt: Date.now(),
    completed: false,
    bridged: false
  });
  await savePending();
  return requestId;
}

// Injects the bridge into the workspace tab once it's actually loaded.
// `chrome.scripting.executeScript` requires host permission for that tab's
// origin, already satisfied here because openWorkspace() only ever
// navigates to an origin in BRIDGE_ALLOWED_ORIGINS, which is a subset of
// manifest.json's static host_permissions.
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (changeInfo.status !== 'complete') return;
  await loadPending();
  for (const [id, req] of pendingRequests) {
    if (req.workspaceTabId === tabId && !req.completed) {
      req.bridged = true;
      await savePending();
      chrome.scripting.executeScript({ target: { tabId }, files: ['content/bridge/measure-bridge.js'] }).catch((err) => {
        console.warn('[TurnKey] could not inject measurement bridge into workspace tab', err && err.message);
      });
      break;
    }
  }
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  await loadPending();
  let changed = false;
  for (const [id, req] of pendingRequests) {
    if (req.earthTabId === tabId || req.workspaceTabId === tabId) {
      pendingRequests.delete(id);
      changed = true;
    }
  }
  if (changed) await savePending();
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'TK_OPEN_WORKSPACE') {
    if (!sender.tab || !sender.url || !sender.url.startsWith(EARTH_ORIGIN)) {
      sendResponse({ ok: false, error: 'Measurement workspace can only be opened from Google Earth.' });
      return false;
    }
    openWorkspace(msg.payload, sender.tab.id)
      .then((requestId) => sendResponse({ ok: true, requestId }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (msg && msg.type === 'TK_MEASURE_RETURN') {
    (async () => {
      await sweepExpired();
      const req = pendingRequests.get(msg.requestId);
      if (!req?.accepted || !sender.tab || sender.tab.id !== req.workspaceTabId) {
        sendResponse({ ok: false, error: 'This measurement has not been accepted from this workspace.' });
        return;
      }
      try {
        const earth = await chrome.tabs.update(req.earthTabId, { active: true });
        if (Number.isInteger(earth?.windowId)) await chrome.windows.update(earth.windowId, { focused: true });
      } catch {
        sendResponse({ ok: false, error: 'Measurement saved. Return to the original Google Earth tab and close this tab.' });
        return;
      }
      pendingRequests.delete(msg.requestId);
      await savePending();
      sendResponse({ ok: true });
      // Navigation failures cannot undo an accepted measurement or trigger a resend.
      try { await chrome.tabs.remove(req.workspaceTabId); }
      catch (error) { console.warn('[TurnKey] measurement saved; close workspace manually', error?.message); }
    })();
    return true;
  }

  if (msg && msg.type === 'TK_MEASURE_RESULT') {
    (async () => {
      await sweepExpired();
      const req = pendingRequests.get(msg.requestId);
      if (!req) {
        sendResponse({ ok: false, error: 'This measurement request has expired or was never opened by this extension.' });
        return;
      }
      // Anti-spoof: the result must come from the exact workspace tab this
      // extension itself opened for this requestId — a random page
      // guessing/replaying a requestId, or a different tab entirely, is
      // rejected. This check (and the `completed` dedupe below) is backed
      // by storage.session, so it still holds even if the worker was
      // killed and restarted since the request was opened.
      if (!sender.tab || sender.tab.id !== req.workspaceTabId) {
        sendResponse({ ok: false, error: 'This measurement did not come from the expected TurnKey workspace tab.' });
        return;
      }
      if (req.completed) {
        sendResponse({ ok: false, error: 'This measurement was already sent.' });
        return;
      }
      req.completed = true;
      await savePending();
      try {
        const ack = await chrome.tabs.sendMessage(req.earthTabId, {
          type: 'TK_MEASURE_COMPLETE',
          requestId: msg.requestId,
          category: req.category,
          kind: req.kind,
          result: msg.result
        });
        if (!ack?.ok) throw new Error('The Earth toolbar could not accept this measurement.');
        req.accepted = true;
        await savePending();
        sendResponse({ ok: true });
        // Retain the completed request until the bridge has acknowledged the
        // page and asks to return. This prevents closing before a successful ACK.
      } catch {
        req.completed = false;
        req.accepted = false;
        sendResponse({ ok: false, error: 'The Google Earth toolbar could not accept this measurement. Keep the original Earth tab open and retry.' });
      }
      await savePending();
    })();
    return true;
  }

  return false;
});

// ── 3. Scoped TurnKey API proxy ─────────────────────────────────────────
// Only these named operations are reachable from content scripts/popup —
// deliberately not a generic "fetch this URL"/"run this REST path" proxy.
const API_ACTIONS = new Set([
  'refresh', 'getProfile', 'getBusiness',
  'listCustomers', 'getCustomer', 'getJob', 'saveBoundQuote', 'createCustomer', 'createQuote', 'createJob',
  'getPricingLearningState', 'submitPricingLearning', 'logActivity', 'uploadScreenshotDataUrl', 'sendQuoteToServiceM8', 'serviceM8TransferStatus'
]);

let client = null;
let clientLoading = null;
let apiConnectionGeneration = 0;
function makeClient(config, session, generation) {
  return new TurnKeyClient(config, session, async (next) => {
    if (generation !== apiConnectionGeneration) throw new Error('Your account changed. Reconnect before continuing.');
    await Storage.setSession(next);
  }, previous => recoverFromCRM(chrome, config, previous));
}
async function ensureClient() {
  if (client) return client;
  if (clientLoading) return clientLoading;
  const generation = apiConnectionGeneration;
  const loading = (async () => {
    const { config, session } = await Storage.loadAll();
    if (generation !== apiConnectionGeneration) throw new Error('Your account changed. Please retry.');
    if (!config) return null;
    client = makeClient(config, session, generation);
    return client;
  })();
  clientLoading = loading;
  try { return await loading; }
  finally { if (clientLoading === loading) clientLoading = null; }
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (connectionChanged(changes) || changes.tk_config) {
    apiConnectionGeneration++;
    client = null;
    clientLoading = null;
  } else if (changes.tk_session && client) {
    // Keep the shared refresh lock alive when only the token pair rotates.
    client.session = changes.tk_session.newValue || null;
  }
});

async function handleApiAction(action, args) {
  const generation = apiConnectionGeneration;
  const c = await ensureClient();
  if (!c) throw new Error('Not connected to a TurnKey site yet.');
  if (action === 'saveBoundQuote') {
    return c.saveBoundQuote(...args, async () => {
      if (generation !== apiConnectionGeneration) throw new Error('Your account changed. Reopen this opportunity before saving.');
    });
  }
  if (action === 'uploadScreenshotDataUrl') {
    const [businessId, customerId, jobId, dataUrl] = args;
    return c.uploadScreenshot(businessId, customerId, jobId, dataUrlToBlob(dataUrl));
  }
  return c[action](...args);
}

async function connectFromActiveCRM(sender) {
  if (!sender || sender.id !== chrome.runtime.id ||
      !String(sender.url || '').startsWith('chrome-extension://' + chrome.runtime.id + '/popup/')) {
    throw new Error('Open the TurnKey extension popup to connect your account.');
  }
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  let siteOrigin;
  try { siteOrigin = new URL(tab && tab.url).origin; } catch { siteOrigin = ''; }
  if (!tab || !Number.isInteger(tab.id) || !TURNKEY_CRM_ORIGINS.has(siteOrigin)) {
    throw new Error('Open a TurnKey tab, sign in, then choose Connect to TurnKey from the extension.');
  }

  const config = await fetchSiteConfig(siteOrigin);
  let supabaseOrigin;
  try { supabaseOrigin = new URL(config.supabaseUrl).origin; } catch { supabaseOrigin = ''; }
  if (supabaseOrigin !== TURNKEY_SUPABASE_ORIGIN) {
    throw new Error('This TurnKey deployment uses an unapproved Supabase project. Contact support to connect it safely.');
  }
  const hasPermission = await chrome.permissions.contains({ origins: [supabaseOrigin + '/*'] });
  if (!hasPermission) throw new Error('Allow the TurnKey database permission in the popup, then retry.');

  const projectRef = new URL(config.supabaseUrl).hostname.split('.')[0];
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content/bridge/customer-launch.js'] });
  } catch {
    throw new Error('Could not connect to this TurnKey tab. Refresh it and try again.');
  }
  let result;
  try {
    result = await chrome.tabs.sendMessage(tab.id, {
      type: 'TK_READ_CRM_AUTH_SESSION',
      storageKey: 'sb-' + projectRef + '-auth-token'
    });
  } catch {
    throw new Error('Could not read the TurnKey sign-in from this tab. Refresh it and try again.');
  }
  if (!result || !result.ok || !result.session) {
    throw new Error(result && result.error || 'Sign in to TurnKey in the active tab, then try again.');
  }

  const verified = new TurnKeyClient(config, null);
  await verified.adoptSession(result.session);
  const profile = await verified.getRequiredProfile();
  const business = await verified.getBusiness(profile.business_id);
  if (!business || String(business.id) !== profile.business_id) {
    throw new Error('Your TurnKey business profile could not be loaded. Refresh TurnKey and retry.');
  }
  await Storage.connect({ config, session: verified.session, profile, business });
  client = makeClient(config, verified.session, apiConnectionGeneration);
  return { profile: { business_id: profile.business_id, role: profile.role, name: profile.name, email: profile.email }, business: { id: business.id, name: business.name } };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'TK_CONNECT_FROM_ACTIVE_CRM') return false;
  connectFromActiveCRM(sender)
    .then((data) => sendResponse({ ok: true, data }))
    .catch((err) => sendResponse({ ok: false, error: err.message }));
  return true;
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'TK_API') return false;
  if (!API_ACTIONS.has(msg.action)) {
    sendResponse({ ok: false, error: 'Unsupported API action.' });
    return false;
  }
  handleApiAction(msg.action, msg.args || [])
    .then((data) => sendResponse({ ok: true, data }))
    .catch((err) => sendResponse({ ok: false, error: err.message }));
  return true;
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type !== 'TK_OPEN_TURNKEY') return false;
  let allowed = sender.id === chrome.runtime.id;
  try {
    const source = new URL(sender.url || sender.tab?.url || '');
    allowed = allowed && (source.origin === 'https://earth.google.com' || source.protocol === 'chrome-extension:');
  } catch { allowed = false; }
  if (!allowed) { sendResponse({ok:false,error:'Open TurnKey from the extension.'}); return false; }
  (async () => {
    const config = await Storage.getConfig();
    if (!config?.siteUrl || !BRIDGE_ALLOWED_ORIGINS.has(new URL(config.siteUrl).origin)) throw new Error('Connect the extension to TurnKey first.');
    return openTurnKeyTab(chrome, config.siteUrl, msg.url);
  })().then(data => sendResponse({ok:true,data}), error => sendResponse({ok:false,error:error.message}));
  return true;
});
