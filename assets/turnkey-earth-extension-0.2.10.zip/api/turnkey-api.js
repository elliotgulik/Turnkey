// TurnKey API client for the Chrome extension.
//
// Deliberately hand-rolled REST calls instead of bundling @supabase/supabase-js
// — this mirrors quote.html's own callRpc()/fetch() pattern (see
// quote.html:178-189), which is already how the rest of this no-build-step
// codebase talks to Supabase from a page that isn't the full CRM SPA. Manifest
// V3 also forbids remotely-hosted code, so vendoring the whole SDK would mean
// shipping/maintaining a local bundle for a handful of endpoints this file
// already covers directly.
//
// Auth model: adopt the active TurnKey CRM tab's session through the private
// extension messaging channel, validate it with Supabase Auth, then keep the
// resulting access/refresh token pair in chrome.storage.local. Every table
// call below sends that access token as the Authorization bearer — RLS's
// current_business_id()/current_business_role() (see
// backend/supabase/fix-rls-recursion.sql) then scopes every read/write to the
// signed-in operator's own business exactly the way it scopes index.html,
// with no extension-specific server code required.

/**
 * Fetches and parses a TurnKey deployment's public config.js — the same file
 * index.html/booking.html/quote.html load for backendUrl/supabaseUrl/
 * supabaseAnonKey/mapsKey. These are documented in config.js itself as safe
 * to expose client-side (anon key + RLS, maps key + HTTP-referrer
 * restriction), so reading them at runtime from the business's own deployed
 * site — rather than hardcoding any one business's values into the extension
 * — is how the extension supports whatever TurnKey site the operator points
 * it at, and stays correct if that business ever rotates its anon key.
 */
// Pulls one `key: 'value'`/`key: "value"` pair out of the config object
// literal's source text. Deliberately not a dynamic-code-execution parse
// (the kind MV3's default extension-pages CSP forbids outright) — and
// executing a string fetched over the network (even from a
// site the operator trusts) is a bigger blast radius than this needs: every
// field config.js actually exposes is a plain string literal, so a single
// allowlisted regex per known key is both sufficient and exactly as safe as
// generate-config.js's own symmetric read of this same file (see its
// mapsKey/onesignalAppId carry-forward regexes).
function extractConfigString(source, key) {
  const match = source.match(new RegExp(key + "\\s*:\\s*(['\"])((?:(?!\\1).)*)\\1"));
  return match ? match[2] : '';
}

export async function fetchSiteConfig(siteUrl) {
  const base = siteUrl.replace(/\/+$/, '');
  const res = await fetch(base + '/config.js', { cache: 'no-store' });
  if (!res.ok) throw new Error('Could not reach ' + base + ' (HTTP ' + res.status + ')');
  const text = await res.text();
  if (!/window\.TURNKEY_CONFIG\s*=/.test(text)) {
    throw new Error('That site does not look like a TurnKey deployment (no config.js found)');
  }
  const supabaseUrl = extractConfigString(text, 'supabaseUrl');
  const supabaseAnonKey = extractConfigString(text, 'supabaseAnonKey');
  if (!supabaseUrl || !supabaseAnonKey) {
    throw new Error('That site\'s config.js is missing supabaseUrl/supabaseAnonKey');
  }
  return {
    siteUrl: base,
    backendUrl: extractConfigString(text, 'backendUrl'),
    supabaseUrl,
    supabaseAnonKey,
    mapsKey: extractConfigString(text, 'mapsKey')
  };
}

export const TURNKEY_CRM_ORIGINS = new Set([
  'https://turnkeycrm.net',
  'http://localhost',
  'http://localhost:5173',
  'http://localhost:8888',
  'http://127.0.0.1',
  'http://127.0.0.1:5173',
  'http://127.0.0.1:8888'
]);

export const TURNKEY_SUPABASE_ORIGIN = 'https://rcighpmdrutnghsqhzlr.supabase.co';

export class TurnKeyClient {
  /**
   * @param {{supabaseUrl:string, supabaseAnonKey:string, backendUrl?:string}} cfg
   * @param {{accessToken:string, refreshToken:string}|null} session
   */
  /**
   * @param {*} cfg
   * @param {*} session
   * @param {(session:object)=>void} [onSessionChange] Called with the fresh
   *   session whenever signIn()/refresh() succeeds. Supabase ROTATES the
   *   refresh token on every use — without persisting the new one, any
   *   other context holding the now-stale token (e.g. the popup, if the
   *   content script refreshed first) would fail to refresh and force a
   *   full re-sign-in. Wire this to Storage.setSession() at the call site.
   */
  constructor(cfg, session, onSessionChange) {
    this.cfg = cfg;
    this.session = session || null;
    this.onSessionChange = onSessionChange || (() => {});
  }

  /**
 * Adopt an existing CRM session only after Supabase validates its bearer
 * token. If the access token expired, rotate it with the supplied refresh
 * token. The user id comes from /auth/v1/user, never from page storage.
   */
  async adoptSession(stored) {
    const accessToken = stored && (stored.access_token || stored.accessToken);
    const refreshToken = stored && (stored.refresh_token || stored.refreshToken);
    if (typeof accessToken !== 'string' || !accessToken || typeof refreshToken !== 'string' || !refreshToken) {
      throw new Error('No active TurnKey sign-in was found in this tab. Sign in to TurnKey, then retry.');
    }
    const rawExpiry = Number(stored.expires_at || stored.expiresAt);
    this.session = {
      accessToken,
      refreshToken,
      userId: null,
      expiresAt: Number.isFinite(rawExpiry) && rawExpiry > 0
        ? (rawExpiry < 1e12 ? rawExpiry * 1000 : rawExpiry)
        : Date.now()
    };
    const loadUser = async () => {
      const res = await fetch(this.cfg.supabaseUrl + '/auth/v1/user', {
        headers: { apikey: this.cfg.supabaseAnonKey, Authorization: 'Bearer ' + this.session.accessToken }
      });
      const text = await res.text();
      let user = null;
      try { user = text ? JSON.parse(text) : null; } catch { /* handled below */ }
      return { res, user };
    };
    let { res, user } = await loadUser();
    if (!res.ok && res.status === 401) {
      try { await this.refresh(); } catch { /* report one safe session error below */ }
      ({ res, user } = await loadUser());
    }
    if (!res.ok || !user || typeof user.id !== 'string') {
      throw new Error('The TurnKey session could not be verified. Refresh TurnKey and try connecting again.');
    }
    this.session.userId = user.id;
    if (this.session.expiresAt - Date.now() < 60000) await this.refresh();
    this.onSessionChange(this.session);
    return this.session;
  }

  async refresh() {
    if (!this.session || !this.session.refreshToken) throw new Error('Not signed in');
    const res = await fetch(this.cfg.supabaseUrl + '/auth/v1/token?grant_type=refresh_token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', apikey: this.cfg.supabaseAnonKey },
      body: JSON.stringify({ refresh_token: this.session.refreshToken })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error_description || 'Session expired — please sign in again');
    this.session = {
      accessToken: data.access_token,
      refreshToken: data.refresh_token,
      userId: data.user ? data.user.id : this.session.userId,
      expiresAt: Date.now() + (data.expires_in || 3600) * 1000
    };
    this.onSessionChange(this.session);
    return this.session;
  }

  async _ensureFreshSession() {
    if (!this.session) throw new Error('Not signed in');
    if (this.session.expiresAt - Date.now() < 60000) await this.refresh();
  }

  async _rest(path, opts = {}) {
    await this._ensureFreshSession();
    const res = await fetch(this.cfg.supabaseUrl + '/rest/v1/' + path, {
      ...opts,
      headers: {
        apikey: this.cfg.supabaseAnonKey,
        Authorization: 'Bearer ' + this.session.accessToken,
        'Content-Type': 'application/json',
        ...(opts.headers || {})
      }
    });
    if (res.status === 204 && res.ok) return null;
    const text=await res.text();
    let body=null;
    if(text.trim()){
      try{body=JSON.parse(text);}
      catch{throw new Error('TurnKey returned an unreadable response (HTTP '+res.status+'). Please retry; an existing draft will be reused.');}
    }
    if (!res.ok) {
      body ||= {};
      throw new Error(body.message || body.error_description || ('Request failed (HTTP ' + res.status + ')'));
    }
    // PostgREST return=minimal commonly uses 201 with NO body, not 204.
    // A successful note write must not make an already saved quote fail.
    if(body===null && (opts.method||'GET')==='GET')throw new Error('TurnKey returned no data for this read. Please retry.');
    return body;
  }

  async _salesBackend(path, businessId, options = {}) {
    const profile=await (path.startsWith('/api/pricing-learning/')?this.getRequiredProfile():this.getProfile());
    if(profile.business_id!==businessId)throw new Error('The extension is signed in to a different business. Reconnect before continuing.');
    if(!this.cfg.backendUrl)throw new Error('TurnKey backend is not configured. Your quote is still saved.');
    if(typeof chrome!=='undefined'&&chrome.permissions){
      const granted=await chrome.permissions.contains({origins:[new URL(this.cfg.backendUrl).origin+'/*']});
      if(!granted)throw new Error('Open the TurnKey extension icon and enable backend access for quote learning and ServiceM8, then retry here.');
    }
    await this._ensureFreshSession();
    options.signal?.throwIfAborted();
    const res=await fetch(this.cfg.backendUrl.replace(/\/$/,'')+path,{
      ...options,headers:{Authorization:'Bearer '+this.session.accessToken,'Content-Type':'application/json'},signal:options.signal||AbortSignal.timeout(30000)
    });
    const text=await res.text();let body={};
    try{body=text.trim()?JSON.parse(text):{}}catch{throw new Error('Could not read the backend response. Your quote remains saved; retry safely.');}
    if(!res.ok)throw new Error(body.error||'Backend request failed. Your TurnKey draft is still saved.');
    return body;
  }

  async _pricingLearningBackend(path,businessId,options={},deadlineMs=1500){
    const controller=new AbortController();let timer;
    try {
      return await Promise.race([
        this._salesBackend(path,businessId,{...options,signal:controller.signal}),
        new Promise((_,reject)=>{timer=setTimeout(()=>{controller.abort();reject(new Error('Quote learning timed out. Continue with base pricing or retry learning for your saved quote.'));},deadlineMs);})
      ]);
    }finally{clearTimeout(timer);}
  }

  async getPricingLearningState(businessId){
    return this._pricingLearningBackend('/api/pricing-learning/state',businessId);
  }

  async submitPricingLearning(businessId,payload){
    if(!payload?.quoteKey||!payload?.jobId||!Array.isArray(payload.lines))throw new Error('Missing saved quote learning context.');
    return this._pricingLearningBackend('/api/pricing-learning/observations',businessId,{method:'POST',body:JSON.stringify(payload)},2500);
  }

  async sendQuoteToServiceM8(businessId,jobId){
    if(!/^[0-9a-f-]{36}$/i.test(jobId))throw new Error('Invalid saved job reference.');
    const result=await this._salesBackend('/api/sales/servicem8/handoff',businessId,{method:'POST',body:JSON.stringify({jobId,mode:'quote'})});
    if(result.queued!==true)throw new Error('ServiceM8 did not confirm the transfer was queued. Your quote is still saved.');
    return {queued:true};
  }

  async serviceM8TransferStatus(businessId,jobId){
    if(!/^[0-9a-f-]{36}$/i.test(jobId))throw new Error('Invalid saved job reference.');
    return this._salesBackend('/api/extension/servicem8/jobs/'+encodeURIComponent(jobId),businessId);
  }

  /** business_id + role for the signed-in user — same lookup as index.html's resolveProfile(). */
  async getProfile() {
    await this._ensureFreshSession();
    const rows = await this._rest('users?id=eq.' + this.session.userId + '&select=business_id,role,name,email');
    const row = rows && rows[0];
    return row && row.business_id ? row : { business_id: this.session.userId, role: 'owner' };
  }

  /** Must return a real tenant mapping for automatic account connection. */
  async getRequiredProfile() {
    const rows = await this._rest('users?id=eq.' + encodeURIComponent(this.session.userId) + '&select=business_id,role,name,email');
    const row = rows && rows[0];
    if (!row || typeof row.business_id !== 'string' || !row.business_id) {
      throw new Error('Your TurnKey login has no business profile. Ask a business owner to finish account setup.');
    }
    return row;
  }

  async getBusiness(businessId) {
    const rows = await this._rest('businesses?id=eq.' + encodeURIComponent(businessId) + '&select=*');
    return rows && rows[0] ? rows[0] : null;
  }

  /** Substring search over this business's customers — same client-side-filter model index.html uses (no server-side search endpoint exists). */
  async listCustomers(businessId) {
    return this._rest('customers?business_id=eq.' + encodeURIComponent(businessId) + '&select=id,business_id,name,email,phone,address,suburb,notes,source&order=created_at.desc&limit=500');
  }

  /** Single customer, scoped to the business — used by the customer→Google Earth handoff (background/customer-handoff.js) to get the authoritative saved address before ever opening a tab. */
  async getCustomer(businessId, customerId) {
    const rows = await this._rest('customers?id=eq.' + encodeURIComponent(customerId) + '&business_id=eq.' + encodeURIComponent(businessId) + '&select=id,business_id,name,email,phone,address,suburb,notes,source');
    const customer = rows?.[0];
    return customer && customer.id === customerId && customer.business_id === businessId ? customer : null;
  }

  /** Exact job lookup: never guess the latest job for a customer. */
  async getJob(businessId, jobId, customerId) {
    const rows = await this._rest('jobs?id=eq.' + encodeURIComponent(jobId) + '&business_id=eq.' + encodeURIComponent(businessId) + '&customer_id=eq.' + encodeURIComponent(customerId) + '&select=id,business_id,customer_id,quote_id,status,details');
    const job = rows?.[0];
    if (!job || job.business_id !== businessId || job.customer_id !== customerId || job.id !== jobId) return null;
    return job;
  }

  /** Save to the exact launched opportunity; never substitute another job. */
  async saveBoundQuote(businessId, {binding, quoteId, total, details}, assertConnection = async () => {}) {
    const assertBusiness = async () => {
      if ((await this.getProfile()).business_id !== businessId || binding.businessId !== businessId) throw new Error('Your business changed. Reopen the quote before saving.');
      await assertConnection();
    };
    await assertBusiness();
    const job = await this.getJob(businessId, binding.jobId, binding.customerId);
    if (!job || !['new','contacted','qualified','quoted','followup','quoting'].includes(job.status)) throw new Error('This opportunity is no longer editable. Reopen it in TurnKey.');
    const targetQuoteId = binding.quoteId || quoteId;
    if ((job.quote_id || null) !== (binding.quoteId || null) && job.quote_id !== targetQuoteId) throw new Error('The linked quote changed. Reopen this opportunity.');
    const quotePath = 'quotes?id=eq.' + encodeURIComponent(targetQuoteId) + '&business_id=eq.' + encodeURIComponent(businessId) + '&lead_id=eq.' + encodeURIComponent(binding.customerId);
    let quote;
    if (binding.quoteId || job.quote_id) {
      const rows = await this._rest(quotePath + '&select=*');
      quote = rows?.[0];
      if (!quote || quote.status !== 'draft') throw new Error('This quote is already sent or approved. Edit it in TurnKey.');
      await assertBusiness();
      const saved = await this._rest(quotePath + '&status=eq.draft&amount=eq.' + encodeURIComponent(quote.amount), {
        method:'PATCH', headers:{Prefer:'return=representation'}, body:JSON.stringify({amount:total})
      });
      quote = saved?.[0];
      if (!quote) throw new Error('The quote changed while saving. Reopen this opportunity.');
    } else {
      quote = await this.createQuote(businessId, {id:targetQuoteId, customerId:binding.customerId, amount:total});
    }
    await assertBusiness();
    // Preserve enquiry/request/operational fields and reject a concurrent edit.
    const merged = {...job.details, ...details};
    const path = 'jobs?id=eq.' + encodeURIComponent(job.id) + '&business_id=eq.' + encodeURIComponent(businessId) + '&customer_id=eq.' + encodeURIComponent(binding.customerId)
      + '&status=eq.' + encodeURIComponent(job.status) + '&quote_id=' + (job.quote_id ? 'eq.' + encodeURIComponent(job.quote_id) : 'is.null')
      + (job.details == null ? '&details=is.null' : '&details=eq.' + encodeURIComponent(JSON.stringify(job.details)));
    let saved;
    try {
      const rows = await this._rest(path, {method:'PATCH', headers:{Prefer:'return=representation'}, body:JSON.stringify({quote_id:targetQuoteId, status:job.status, details:merged})});
      saved = rows?.[0];
      if (!saved) throw new Error('The opportunity changed while saving. Reopen it in TurnKey.');
    } catch (error) {
      // A lost PATCH response may already have saved the exact same draft.
      const current = await this.getJob(businessId, job.id, binding.customerId);
      const same = current?.quote_id === targetQuoteId && Object.entries(details).every(([key,value]) => JSON.stringify(current.details?.[key]) === JSON.stringify(value));
      if (!same) throw error;
      saved = current;
    }
    return {quote, job:saved};
  }

  async createCustomer(businessId, payload) {
    return this._createStable('customers', { ...payload, business_id: businessId });
  }

  // A lost HTTP response must not turn Retry into a second database row.
  // Stable UUIDs use the database primary key for concurrency protection.
  // Recovery reads are scoped to the business and checked against the
  // intended contents; an existing different row is never overwritten.
  async _createStable(table, payload) {
    try {
      const rows = await this._rest(table, {method:'POST',headers:{Prefer:'return=representation'},body:JSON.stringify(payload)});
      if (!rows?.[0]) throw new Error('The database did not confirm the saved record.');
      return rows[0];
    } catch (error) {
      if (!payload.id) throw error;
      const rows=await this._rest(table+'?id=eq.'+encodeURIComponent(payload.id)+'&business_id=eq.'+encodeURIComponent(payload.business_id)+'&select=*');
      const row=rows?.[0];
      const sort=value=>Array.isArray(value)?value.map(sort):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(k=>[k,sort(value[k])])):value;
      const canonical=value=>JSON.stringify(sort(value));
      if (!row || !Object.entries(payload).every(([key,value])=>canonical(row[key])===canonical(value))) throw error;
      return row;
    }
  }

  /**
   * Creates a DRAFT quote — matches index.html's own convention
   * (`status: r.quoteSentAt ? 'sent' : 'draft'`, index.html's
   * syncRecordToSupabase()). The extension has no "send to customer" step
   * of its own (no email/SMS is triggered here), so marking it 'sent'
   * would claim an action that never happened; the operator sends it for
   * real from TurnKey itself (see quote.js's "Open in TurnKey" / "Copy
   * Quote Link").
   */
  async createQuote(businessId, { id, customerId, amount }) {
    return this._createStable('quotes', { ...(id ? {id} : {}), business_id: businessId, lead_id: customerId, amount, status:'draft' });
  }

  async createJob(businessId, { id, customerId, quoteId, details }) {
    return this._createStable('jobs', {
        ...(id ? {id} : {}),
        business_id: businessId,
        customer_id: customerId,
        quote_id: quoteId,
        status: 'quoted',
        details
    });
  }

  async logActivity(businessId, { customerId, jobId, type, summary, detail }) {
    await this._ensureFreshSession();
    return this._rest('activity_log', {
      method: 'POST',
      body: JSON.stringify({
        business_id: businessId,
        customer_id: customerId,
        job_id: jobId || null,
        type,
        summary,
        detail: detail || null,
        // Attributes the timeline entry to the signed-in operator, same as
        // every staff-initiated activity_log row the CRM itself writes —
        // see activityActorLabel() in index.html, which resolves this
        // against public.users to show a real staff name.
        created_by: this.session.userId
      })
    });
  }

  /**
   * Uploads a screenshot to the same private bucket/path convention index.html's
   * uploadAttachment() uses ({business_id}/{kind}/{ts}-{rand}-{filename}), so it
   * shows up in the CRM's existing photo/attachment views with zero CRM changes.
   */
  async uploadScreenshot(businessId, customerId, jobId, blob) {
    await this._ensureFreshSession();
    const filename = 'property-screenshot.png';
    const path = businessId + '/quote_attachment/' + Date.now() + '-' + Math.random().toString(36).slice(2, 8) + '-' + filename;
    const res = await fetch(this.cfg.supabaseUrl + '/storage/v1/object/turnkey-uploads/' + path, {
      method: 'POST',
      headers: {
        apikey: this.cfg.supabaseAnonKey,
        Authorization: 'Bearer ' + this.session.accessToken,
        'Content-Type': 'image/png'
      },
      body: blob
    });
    if (!res.ok) throw new Error('Screenshot upload failed (HTTP ' + res.status + ')');
    const row = await this._rest('attachments', {
      method: 'POST',
      headers: { Prefer: 'return=representation' },
      body: JSON.stringify({
        business_id: businessId,
        customer_id: customerId,
        job_id: jobId || null,
        kind: 'quote_attachment',
        path,
        filename
      })
    });
    return row[0];
  }
}
